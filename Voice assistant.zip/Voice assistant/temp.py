import streamlit as st
import speech_recognition as sr
import Levenshtein
from beepy import beep



def checkSimilarity(phrase, wakeup_phrase):
    distance = Levenshtein.distance(phrase, wakeup_phrase)
    max_length = max(len(phrase), len(wakeup_phrase))
    similarity_ratio = 1 - (distance / max_length)
    return similarity_ratio > 0.3


# Function to listen for a wakeup phrase
def listen_for_wakeup_phrase(wakeup_phrase):
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()
    
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)
        st.text("Listening for wakeup phrase...")
        audio = recognizer.listen(source)
        
    try:
        phrase = recognizer.recognize_google(audio)
        print(phrase)
        # check if the output phrase is the more than 50% similar to the wakeup phrase
        
        if phrase.lower() == wakeup_phrase.lower() or checkSimilarity(phrase, wakeup_phrase):
            st.text("Wakeup phrase recognized!")
            return True
        else:
            st.text("Wakeup phrase not recognized. Listening again...")
            return False
    except sr.UnknownValueError:
        st.text("Could not understand audio. Listening again...")
        return False
    except sr.RequestError as e:
        st.text(f"Error: {e}")
        return False

# Main Streamlit app
def main():
    page = st.sidebar.radio("Go to", ["Home", "About"])
    if page == "Home":
        st.title("Voice Recorder with Wakeup Phrase")
    else:
        st.title("Voice Recorder with Wakeup Phrase")
        wakeup_phrase = "Hey Anza"
        # wakeup_phrase = st.text_input("Enter the wakeup phrase:", wakeup_phrase)

        while True:
            
            if listen_for_wakeup_phrase(wakeup_phrase):
                
                beep(sound='ping')
                st.write("Recording...")
                break
        

if __name__ == "__main__":
    main()
