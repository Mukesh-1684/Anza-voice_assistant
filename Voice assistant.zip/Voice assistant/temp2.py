import streamlit as st
import geocoder
g = geocoder.ip('me')
if g.latlng is not None:
    latitude, longitude = g.latlng
    dataframe = {
        "LATITUDE": [latitude],
        "LONGITUDE": [longitude],
    }
    st.map(dataframe)